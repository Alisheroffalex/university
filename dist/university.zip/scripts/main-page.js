$(".header-carousel").slick({
    dots: true,
    infinite: false,
    speed: 500,
    fade: true,
    // autoplay: true,
    cssEase: 'linear',
    arrows: true,
    dotsClass: 'slick-dots',
    prevArrow: '.h-carousel-prev',
    nextArrow: '.h-carousel-next'
});
$(".f-carousel").slick({
    dots: false,
    infinite: true,
    speed: 500,
    autoplay: true,
    arrows: false,
    slidesToShow: 5,
    slidesToScroll: 1,
    variableWidth: true,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: false
            }
        },
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 1,
                variableWidth: false,
                slidesToScroll: 1
            }
        },
    ]
});
$('.search').click(function (event) {
    var parent = $(event.target).parent().parent();
    event.preventDefault();
    $(parent).addClass('active');
    $('.burger-wrapper').addClass('active');
    $('#overlay').addClass('active');
    $('#overlay').click(function () {
        parent.removeClass('active');
        $('#overlay').removeClass('active');
    });
    $('.burger-wrapper').click(function () {
        parent.removeClass('active');
        $('.burger-wrapper').removeClass('active');
        $('#overlay').removeClass('active');
    });
});
$('.burger-toggle').click(function () {
    $('.burger-wrapper').addClass('active');
    $('.navbar').addClass('active');
    $('.menu-mobile').addClass('active');
    $('.burger-close').click(function () {
        $('.burger-wrapper').removeClass('active');
        $('.navbar').removeClass('active');
        $('.menu-mobile').removeClass('active');
    });
});
$('.mobile-ul-menu li i').on('click', function () {
    $(this).parent().find('.dropdown-menu').first().toggleClass('dropdown-open');
    $('.dropdown-menu li').on('click', function () {
        $(this).find('.dropdown-menu').first().toggleClass('dropdown-open');
    });
});
$(window).scroll(function () {
    var scroll = $(window).scrollTop();
    //>=, not <=
    if (scroll >= 50) {
        //clearHeader, not clearheader - caps H
        $(".navbar").addClass("active");
    }
    else {
        $(".navbar").removeClass("active");
    }
});
$('.f-navigation .small-header').on('click', function () {
    $(this).parent().toggleClass('active');
});
